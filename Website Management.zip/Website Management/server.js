console.log('Jai Hanumaan Ji');
const express = require('express');
const server = express();
server.use(express.urlencoded({extended:false}));
require('dotenv').config();
const session = require('express-session');
const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/project1').then(()=>{console.log('Connected to DB(Project1)')}).catch((error)=>{console.log(error.message)});

const adminRouter = require('./routers/adminrouter');
const userRouter = require('./routers/userrouter');


server.use(session({
    secret: process.env.SECRET_KEY,
    resave: false,
    saveUninitialized: false
}));
server.use(userRouter);
server.use('/admin', adminRouter);
server.use(express.static('public'));
server.set('view engine', 'ejs');
server.listen(process.env.PORT || 8000, ()=> {console.log(`Server is running on port ${process.env.PORT}`)});