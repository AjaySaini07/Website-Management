const testiTable = require('../models/testitable')


exports.testiForm = (req,res) => {
    const message = req.params.msg
    //console.log(msg)
    res.render('testiform.ejs', {message})
}

exports.testiAdd = (req,res) => {
    //console.log(req.body)
    //console.log(req.file)
    const filename = req.file.filename
    const{fullname,feedback,img} = req.body
    const testiData = new testiTable({postedBy:fullname, desc:feedback, img:filename})
    testiData.save()
    res.redirect('/testiform/Thanks for your feedback...!')
}

exports.testiShow = async(req,res) => {
    //console.log(req.params.msg)
    const message = req.params.msg
    const loginName = req.session.username
    const data = await testiTable.find()
    //console.log(data)
    res.render('admin/testinominal.ejs', {loginName,data,message})
}
exports.testiDelete = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    await testiTable.findByIdAndDelete(id)
    res.redirect('/admin/testishow/Feedback has been successfully deleted...!')
}