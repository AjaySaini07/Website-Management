const registerTable = require('../models/registertable');

exports.loginshow = (req,res) => {
    let error = '';
    res.render('admin/login.ejs', {error});
}
exports.logincheck = async(req,res) => {
    //console.log(req.body);
    let error = null;
    const{username,password} = req.body;
    if(username == '' && password == '') {
        error = 'Please Enter Username & Password..!';
        res.render('admin/login.ejs', {error});
    } else {
        const dataCheck = await registerTable.findOne({username:username});
        //console.log(dataCheck);
        if(dataCheck != null) {
            if(dataCheck.password == password) {
                req.session.isAuth = true;
                req.session.username = username;
                res.redirect('/admin/dashboard');
            } else {
                error = 'Wrong Password...!';
                res.render('admin/login.ejs', {error});
            }
        } else {
            //res.send('Wrong Username...Please Enter Right Username!!');
            error = 'Wrong Username...!';
            res.render('admin/login.ejs', {error});
        }
    }  
}

exports.dashboard = (req,res) => {
    //console.log(req.session);
    const loginName = req.session.username;
    res.render('admin/dashboard.ejs', {loginName});
}
exports.logout = (req,res) => {
    req.session.destroy();
    res.redirect('/admin/');
}
