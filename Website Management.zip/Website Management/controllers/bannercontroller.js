const bannerTable = require('../models/bannertable')
let message = ''
let color = ''

exports.banner = async(req,res) => {
    const loginName = req.session.username
    const data = await bannerTable.findOne()
    //console.log(data);
    res.render('admin/banner.ejs', {loginName,data,message,color})
}
exports.updateform = async(req,res) => {
    //console.log(req.params.id);
    const loginName = req.session.username
    const data = await bannerTable.findById(req.params.id)
    //console.log(data);
    res.render('admin/bannerupdateform.ejs', {loginName,data,message,color})
}
exports.update = async(req,res) => {
    //console.log(req.body);
    //console.log(req.file)
    const filename = req.file.filename
    const{btitle,bdesc,bmoredetail} = req.body
    const id = req.params.id
    const loginName = req.session.username
    if(btitle == '') {
        message = 'Please fill banner title...!'
        color = 'danger'
    }
    else if(btitle.length > 25) {
        message = 'Length of banner title should be less then 25...!'
        color = 'danger'
    }
    else if(bdesc == '') {
        message = 'Please fill banner description...!'
        color = 'danger'
    }
    else if(bmoredetail == '') {
        message = 'Please fill banner more detail...!'
        color = 'danger'
    } 
    // else if(req.filename == '') {
    //     message = 'Please fill banner image...!'
    //     color = 'danger'
    // }
    else {
        await bannerTable.findByIdAndUpdate(id, {title:btitle, desc:bdesc, moredetail:bmoredetail, img:filename})
        var data = await bannerTable.findById(req.params.id)
        message = 'Successfully Updated...!';
        color = 'success'
    }
    res.render('admin/bannerupdateform.ejs', {message,loginName,data,color})
    //res.redirect('/admin/banner');
}

exports.bannerdetail = async(req,res) => {
    const data = await bannerTable.findOne()
    res.render('bannerdetail.ejs', {data,message,color})    
}