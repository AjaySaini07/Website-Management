const queryTable = require('../models/querytable')
const nodemailer = require('nodemailer')



exports.query = (req,res) => {
    //console.log(req.body)
    const{email,query} = req.body
    const newData = new queryTable({email:email, query:query})
    newData.save()
    res.render('querymessage.ejs')
}

exports.queryShow = async(req,res) => {
    //console.log(req.params.mess)
    const message = req.params.mess
    const loginName = req.session.username
    const data = await queryTable.find().sort({status:1})
    //console.log(data)
    res.render('admin/queryshow.ejs', {loginName,data,message})
}
exports.deleteQuery = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    await queryTable.findByIdAndDelete(id)
    res.redirect('/admin/queryshow/Successfully query has been deleted...!')
}

exports.queryreplyForm = async(req, res) => {
    //console.log(req.params.id)
    const id = req.params.id
    const loginName = req.session.username
    const data = await queryTable.findById(id)
    res.render('admin/queryreplyform.ejs', {loginName,data})
}
exports.queryReply = async(req, res) => {
    const id = req.params.id
    //console.log(req.body)
    //console.log(req.file)
    //console.log(req.file.path)
    const{emailfrom,emailto,subject,body} = req.body
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          user: "nodetest0708@gmail.com",
          pass: "kzdyagxtknyrsfao",
        },
    });
    if(req.file) {
        const filePath = req.file.path
        await transporter.sendMail({
            from: "nodetest0708@gmail.com",
            to: emailto,
            subject: subject,
            text: body,
            attachments:[{
                path:filePath
            }]
        });
    } else {
        await transporter.sendMail({
            from: "nodetest0708@gmail.com",
            to: emailto,
            subject: subject,
            text: body,
        });
    }
    await queryTable.findByIdAndUpdate(id, {status:'Replyed'})
    res.redirect('/admin/queryshow/msg')
}