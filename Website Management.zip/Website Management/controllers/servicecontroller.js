const serviceTable = require('../models/servicetable')
let message = ''
let color = ''

exports.service = async(req,res) => {
    //console.log(req.params.msg)
    //console.log(req.query)
    const message = req.params.msg
    const loginName = req.session.username
    if(req.params.msg == 'hit2') {
        var data = await serviceTable.find().sort({postedDate:1})
    } else if(req.params.msg == 'hit1') {
        var data = await serviceTable.find().sort({postedDate:-1})
    } else {
        var data = await serviceTable.find()
    }
    const tserviceCount = await serviceTable.find().count()
    const pserviceCount = await serviceTable.find({status:'Published'}).count()
    const userviceCount = await serviceTable.find({status:'Unpublished'}).count()
    //console.log(serviceCount)
    //console.log(data)
    res.render('admin/service.ejs', {loginName,message,color,data,tserviceCount,pserviceCount,userviceCount}) 
}
exports.serviceform = (req,res) => {
    const loginName = req.session.username
    color = 'success'
    res.render('admin/serviceform.ejs', {loginName,message,color})
}
exports.serviceadd = (req,res) => {
    //console.log(req.body)
    //console.log(req.file)
    const filename = req.file.filename
    const{stitle,sdesc,smoredetail} = req.body
    const loginName = req.session.username
    if(stitle == '') {
        message = 'Please Fill Service Title...!'
        color = 'danger'
    } else if(sdesc == '') {
        message = 'Please Fill Service Description...!'
        color = 'danger'
    } else if(smoredetail == '') {
        message = 'Please Fill Service More Detail...!'
        color = 'danger'
    } else if (req.filename == '') {
        message = 'Please Fill Service Image...!'
        color = 'danger'
    } else {
        const newRecord = serviceTable({title:stitle, desc:sdesc, moredetail:smoredetail, img:filename})
    newRecord.save()
    message = 'Successfully Service Added...!'
    }
    res.redirect(`/admin/service/${message}`)
    //res.render('admin/serviceform.ejs', {loginName,message,color})
}
exports.servicedelete = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    await serviceTable.findByIdAndDelete(id)
    message = 'Successfully Service Deleted...!'
    res.redirect(`/admin/service/${message}`)
}
exports.statusupdate = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    const data = await serviceTable.findById(id)
    //console.log(data)
    let newStatus = null
    if(data.status == 'Unpublished') {
        newStatus = 'Published'
    } else {
        newStatus = 'Unpublished'
    }
    await serviceTable.findByIdAndUpdate(id, {status:newStatus})
    res.redirect('/admin/service/msg')
}
exports.smoredetail = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    const data = await serviceTable.findById(id)
    //console.log(data)
    res.render('servicemoredetail.ejs', {data})
}
