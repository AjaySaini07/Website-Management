const express = require('express')
const router = express.Router()
const registerContro = require('../controllers/registercontroller')
const bannerContro = require('../controllers/bannercontroller')
const serviceContro = require('../controllers/servicecontroller')
const testiContro = require('../controllers/testicontroller')
const bannerTable = require('../models/bannertable')
const serviceTable = require('../models/servicetable')
const queryContro = require('../controllers/querycontroller')
const upload = require('../helper/multer')


router.get('/', async(req,res) => {
    const bannerData = await bannerTable.findOne()
    const serviceData = await serviceTable.find({status:'Published'})
    //console.log(bannerData)
    //console.log(serviceData)
    res.render('home.ejs', {bannerData,serviceData})
});

router.get('/bannerdetail', bannerContro.bannerdetail)

router.get('/servmoredetail/:id', serviceContro.smoredetail)

//router.get('/query', (req,res) => {})
router.post('/query', queryContro.query)



router.get('/testiform/:msg', testiContro.testiForm)
router.post('/testiform/:msg', upload.single('img'), testiContro.testiAdd)







module.exports = router;