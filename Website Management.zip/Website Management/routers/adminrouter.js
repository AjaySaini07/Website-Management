const router = require('express').Router()
const registerContro = require('../controllers/registercontroller')
const bannerContro = require('../controllers/bannercontroller')
const serviceContro = require('../controllers/servicecontroller')
const testiContro = require('../controllers/testicontroller')
const queryContro = require('../controllers/querycontroller')
const securityCheck = require('../middleware/securitycheck')
const bannertable = require('../models/bannertable')
const upload = require('../helper/multer')


router.get('/', registerContro.loginshow)
router.post('/', registerContro.logincheck)
router.get('/dashboard', securityCheck, registerContro.dashboard)
router.get('/logout', registerContro.logout)
router.get('/banner', securityCheck, bannerContro.banner)
router.get('/bannerupdate/:id', securityCheck, bannerContro.updateform)
router.post('/bannerupdate/:id', securityCheck, upload.single('img'), bannerContro.update)
router.get('/service/:msg', serviceContro.service)
router.get('/addservice', serviceContro.serviceform)
router.post('/addservice', upload.single('img'), serviceContro.serviceadd)
router.get('/servicedelete/:id', serviceContro.servicedelete)
router.get('/statusupdate/:id', serviceContro.statusupdate)

router.get('/testishow/:msg', testiContro.testiShow)
router.get('/testidelete/:id', testiContro.testiDelete)

router.get('/queryshow/:mess', queryContro.queryShow)
router.get('/deletequery/:id', queryContro.deleteQuery)
router.get('/queryreply/:id', queryContro.queryreplyForm)
router.post('/queryreply/:id', upload.single('attachment') , queryContro.queryReply)


module.exports = router