const mongoose = require('mongoose');

const serviceSchema = mongoose.Schema({
    img:{
        type:String,
        required:true
    },
    title:{
        type:String,
        required:true
    },
    desc:{
        type:String,
        required:true
    },
    moredetail:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        required:true,
        default:new Date()
    },
    status:{
        type:String,
        default:'Unpublished'
    }
})

module.exports = mongoose.model('service', serviceSchema);