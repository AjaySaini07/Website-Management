const mongoose = require('mongoose')

const querySchema = mongoose.Schema({
    email:{
        type:String,
        required:true
    },
    query:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        required:true,
        default:new Date()
    },
    status:{
        type:String,
        required:true,
        default:'Reply'
    }
})

module.exports = mongoose.model('query', querySchema)