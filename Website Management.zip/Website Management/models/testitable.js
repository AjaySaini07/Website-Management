const mongoose = require('mongoose')

const testiSchema = mongoose.Schema({
    img:{
        type:String
    },
    desc:{
        type:String,
        required:true
    },
    postedBy:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        required:true,
        default:new Date().toString()
    }
})

module.exports = mongoose.model('testi', testiSchema)